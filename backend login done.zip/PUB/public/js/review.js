function poster(){
    let a = document.getElementById("review1").value

    document.getElementById("posting").innerHTML += a

    console.log(a)

}