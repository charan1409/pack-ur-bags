module.exports={
    MongoURI:'mongodb+srv://rahulvarma5297:rahulvarma@cluster0.hptoc.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
}
