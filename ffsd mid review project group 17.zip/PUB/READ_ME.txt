FOR RUNNING PROJECT:

open new terminal and enter the following command:
npm start

Now go to Your deafult website and type this url : http://localhost:3000/